--restaurant--
INSERT IGNORE INTO restaurants (id, name, image, description, lowest_price, highest_price, postal_code, address, opening_time, closing_time, capacity) VALUES (1, 'SAMURAIの店', 'house01.jpg', '焼肉屋', 6000, 12000, '073-0145', '北海道砂川市西五条南X-XX-XX', '10:00:00' ,'23:00:00', 5);
INSERT IGNORE INTO restaurants (id, name, image, description, lowest_price, highest_price, postal_code, address, opening_time, closing_time, capacity) VALUES (2, 'ラーメン天国', 'house02.jpg', '焼肉屋', 2000, 7900, '073-0145', '北海道砂川市西五条南X-XX-XX', '10:00:00' ,'23:00:00', 5);
INSERT IGNORE INTO restaurants (id, name, image, description, lowest_price, highest_price, postal_code, address, opening_time, closing_time, capacity) VALUES (3, 'ラーメン地獄', 'house03.jpg', '焼肉屋', 2500, 5600, '073-0145', '北海道砂川市西五条南X-XX-XX', '10:00:00' ,'23:00:00', 5);
INSERT IGNORE INTO restaurants (id, name, image, description, lowest_price, highest_price, postal_code, address, opening_time, closing_time, capacity) VALUES (4, '名古屋ラーメン', 'house04.jpg', '焼肉屋', 3000, 6900, '073-0145', '北海道砂川市西五条南X-XX-XX', '10:00:00' ,'23:00:00', 5);
INSERT IGNORE INTO restaurants (id, name, image, description, lowest_price, highest_price, postal_code, address, opening_time, closing_time, capacity) VALUES (5, '和食名古屋めし', 'house05.jpg', '焼肉屋', 4000, 5000, '073-0145', '北海道砂川市西五条南X-XX-XX', '10:00:00' ,'23:00:00', 5);
INSERT IGNORE INTO restaurants (id, name, image, description, lowest_price, highest_price, postal_code, address, opening_time, closing_time, capacity) VALUES (6, '名古屋チャーハン', 'house07.jpg', '焼肉屋', 1500, 18000, '073-0145', '北海道砂川市西五条南X-XX-XX', '10:00:00' ,'23:00:00', 5);
INSERT IGNORE INTO restaurants (id, name, image, description, lowest_price, highest_price, postal_code, address, opening_time, closing_time, capacity) VALUES (7, '名古屋ピザ', 'house06.jpg', '焼肉屋', 1600, 9900, '073-0145', '北海道砂川市西五条南X-XX-XX', '10:00:00' ,'23:00:00', 5);
INSERT IGNORE INTO restaurants (id, name, image, description, lowest_price, highest_price, postal_code, address, opening_time, closing_time, capacity) VALUES (8, '韓国風料理屋', 'house08.jpg', '焼肉屋', 4500, 7700, '073-0145', '北海道砂川市西五条南X-XX-XX', '10:00:00' ,'23:00:00', 5);
INSERT IGNORE INTO restaurants (id, name, image, description, lowest_price, highest_price, postal_code, address, opening_time, closing_time, capacity) VALUES (9, 'パスタ名古屋', 'house09.jpg', '焼肉屋', 7000, 8800, '073-0145', '北海道砂川市西五条南X-XX-XX', '10:00:00' ,'23:00:00', 5);
INSERT IGNORE INTO restaurants (id, name, image, description, lowest_price, highest_price, postal_code, address, opening_time, closing_time, capacity) VALUES (10, 'スープ名古屋', 'house10.jpg', '焼肉屋', 6800, 22000, '073-0145', '北海道砂川市西五条南X-XX-XX', '10:00:00' ,'23:00:00', 5);
INSERT IGNORE INTO restaurants (id, name, image, description, lowest_price, highest_price, postal_code, address, opening_time, closing_time, capacity) VALUES (11, 'ガムガム名古屋', 'house01.jpg', '焼肉屋', 3200, 2000, '073-0145', '北海道砂川市西五条南X-XX-XX', '10:00:00' ,'23:00:00', 5);

-- rolesテーブル
INSERT IGNORE INTO roles (id, name) VALUES (1, 'ROLE_GENERAL');
INSERT IGNORE INTO roles (id, name) VALUES (2, 'ROLE_ADMIN');

-- usersテーブル
INSERT IGNORE INTO users (id, name, furigana, postal_code, address, phone_number, birthday, profession, email, password, role_id, enabled) VALUES (1, '侍 太郎', 'サムライ タロウ', '101-0022', '東京都千代田区神田練塀町300番地', '090-1234-5678', '12月12日', 'エンジニア', 'taro.samurai@example.com', '$2a$10$2JNjTwZBwo7fprL2X4sv.OEKqxnVtsVQvuXDkI8xVGix.U3W5B7CO', 1, true);
INSERT IGNORE INTO users (id, name, furigana, postal_code, address, phone_number, birthday, profession, email, password, role_id, enabled) VALUES (2, '侍 花子', 'サムライ ハナコ', '101-0022', '東京都千代田区神田練塀町300番地', '090-1234-5678', '1月1日', 'エンジニア', 'hanako.samurai@example.com', '$2a$10$2JNjTwZBwo7fprL2X4sv.OEKqxnVtsVQvuXDkI8xVGix.U3W5B7CO', 2, true);
INSERT IGNORE INTO users (id, name, furigana, postal_code, address, phone_number, birthday, profession, email, password, role_id, enabled) VALUES (3, '侍 義勝', 'サムライ ヨシカツ', '638-0644', '奈良県五條市西吉野町湯川X-XX-XX', '090-1234-5678', '2月2日', 'エンジニア', 'yoshikatsu.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, name, furigana, postal_code, address, phone_number, birthday, profession, email, password, role_id, enabled) VALUES (4, '侍 義勝', 'サムライ ヨシカツ', '638-0644', '奈良県五條市西吉野町湯川X-XX-XX', '090-1234-5678', '2月2日', 'エンジニア', 'yoshikatsu.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, name, furigana, postal_code, address, phone_number, birthday, profession, email, password, role_id, enabled) VALUES (5, '侍 義勝', 'サムライ ヨシカツ', '638-0644', '奈良県五條市西吉野町湯川X-XX-XX', '090-1234-5678', '2月2日', 'エンジニア', 'yoshikatsu.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, name, furigana, postal_code, address, phone_number, birthday, profession, email, password, role_id, enabled) VALUES (6, '侍 義勝', 'サムライ ヨシカツ', '638-0644', '奈良県五條市西吉野町湯川X-XX-XX', '090-1234-5678', '2月2日', 'エンジニア', 'yoshikatsu.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, name, furigana, postal_code, address, phone_number, birthday, profession, email, password, role_id, enabled) VALUES (7, '侍 義勝', 'サムライ ヨシカツ', '638-0644', '奈良県五條市西吉野町湯川X-XX-XX', '090-1234-5678', '2月2日', 'エンジニア', 'yoshikatsu.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, name, furigana, postal_code, address, phone_number, birthday, profession, email, password, role_id, enabled) VALUES (8, '侍 義勝', 'サムライ ヨシカツ', '638-0644', '奈良県五條市西吉野町湯川X-XX-XX', '090-1234-5678', '2月2日', 'エンジニア', 'yoshikatsu.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, name, furigana, postal_code, address, phone_number, birthday, profession, email, password, role_id, enabled) VALUES (9, '侍 義勝', 'サムライ ヨシカツ', '638-0644', '奈良県五條市西吉野町湯川X-XX-XX', '090-1234-5678', '2月2日', 'エンジニア', 'yoshikatsu.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, name, furigana, postal_code, address, phone_number, birthday, profession, email, password, role_id, enabled) VALUES (10, '侍 義勝', 'サムライ ヨシカツ', '638-0644', '奈良県五條市西吉野町湯川X-XX-XX', '090-1234-5678', '2月2日', 'エンジニア', 'yoshikatsu.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, name, furigana, postal_code, address, phone_number, birthday, profession, email, password, role_id, enabled) VALUES (11, '侍 義勝', 'サムライ ヨシカツ', '638-0644', '奈良県五條市西吉野町湯川X-XX-XX', '090-1234-5678', '2月2日', 'エンジニア', 'yoshikatsu.samurai@example.com', 'password', 1, false);
INSERT IGNORE INTO users (id, name, furigana, postal_code, address, phone_number, birthday, profession, email, password, role_id, enabled) VALUES (12, '侍 義勝', 'サムライ ヨシカツ', '638-0644', '奈良県五條市西吉野町湯川X-XX-XX', '090-1234-5678', '2月2日', 'エンジニア', 'yoshikatsu.samurai@example.com', 'password', 1, false);

-- reservationsテーブル
INSERT IGNORE INTO reservations (id, restaurant_id, user_id, reservation_date, number_of_people) VALUES (1, 1, 1, '2023-04-01',2);
INSERT IGNORE INTO reservations (id, restaurant_id, user_id, reservation_date, number_of_people) VALUES (2, 2, 1, '2023-04-01',3);
INSERT IGNORE INTO reservations (id, restaurant_id, user_id, reservation_date, number_of_people) VALUES (3, 3, 1, '2023-04-01',4);
INSERT IGNORE INTO reservations (id, restaurant_id, user_id, reservation_date, number_of_people) VALUES (4, 4, 1, '2023-04-01',5);
INSERT IGNORE INTO reservations (id, restaurant_id, user_id, reservation_date, number_of_people) VALUES (5, 5, 1, '2023-04-01',6);
INSERT IGNORE INTO reservations (id, restaurant_id, user_id, reservation_date, number_of_people) VALUES (6, 6, 1, '2023-04-01',2);
INSERT IGNORE INTO reservations (id, restaurant_id, user_id, reservation_date, number_of_people) VALUES (7, 7, 1, '2023-04-01',3);
INSERT IGNORE INTO reservations (id, restaurant_id, user_id, reservation_date, number_of_people) VALUES (8, 8, 1, '2023-04-01',4);
INSERT IGNORE INTO reservations (id, restaurant_id, user_id, reservation_date, number_of_people) VALUES (9, 9, 1, '2023-04-01',5);
INSERT IGNORE INTO reservations (id, restaurant_id, user_id, reservation_date, number_of_people) VALUES (10, 10, 1, '2023-04-01',6);
INSERT IGNORE INTO reservations (id, restaurant_id, user_id, reservation_date, number_of_people) VALUES (11, 11, 1, '2023-04-01',2);

-- reviewsテーブル							
INSERT IGNORE INTO reviews (id, restaurant_id, user_id, score, content) VALUES (1, 1, 1, 1, 'テストデータ1');							
INSERT IGNORE INTO reviews (id, restaurant_id, user_id, score, content) VALUES (2, 1, 2, 2, 'テストデータ2');							
INSERT IGNORE INTO reviews (id, restaurant_id, user_id, score, content) VALUES (3, 1, 3, 3, 'テストデータ3');							
INSERT IGNORE INTO reviews (id, restaurant_id, user_id, score, content) VALUES (4, 1, 4, 4, 'テストデータ4');							
INSERT IGNORE INTO reviews (id, restaurant_id, user_id, score, content) VALUES (5, 1, 5, 5, 'テストデータ5');							
						
 -- favoritesテーブル							
 INSERT IGNORE INTO nagoyameshi_db.favorites (id, restaurant_id, user_id) VALUES (1, 1, 1);							
 INSERT IGNORE INTO nagoyameshi_db.favorites (id, restaurant_id, user_id) VALUES (2, 2, 1);							
 INSERT IGNORE INTO nagoyameshi_db.favorites (id, restaurant_id, user_id) VALUES (3, 3, 1);							
 INSERT IGNORE INTO nagoyameshi_db.favorites (id, restaurant_id, user_id) VALUES (4, 4, 1);							
 INSERT IGNORE INTO nagoyameshi_db.favorites (id, restaurant_id, user_id) VALUES (5, 5, 1);							
 INSERT IGNORE INTO nagoyameshi_db.favorites (id, restaurant_id, user_id) VALUES (6, 6, 1);							
 INSERT IGNORE INTO nagoyameshi_db.favorites (id, restaurant_id, user_id) VALUES (7, 7, 1);							
 INSERT IGNORE INTO nagoyameshi_db.favorites (id, restaurant_id, user_id) VALUES (8, 8, 1);							
 INSERT IGNORE INTO nagoyameshi_db.favorites (id, restaurant_id, user_id) VALUES (9, 9, 1);							
 INSERT IGNORE INTO nagoyameshi_db.favorites (id, restaurant_id, user_id) VALUES (10, 10, 1);							
 INSERT IGNORE INTO nagoyameshi_db.favorites (id, restaurant_id, user_id) VALUES (11, 11, 1);							
						
